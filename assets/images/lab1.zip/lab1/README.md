# Setting up

## Installing conda
We need `conda` to setup environments and install packages. To do so we install `miniforge` which is opensource instead of Anaconda. Anaconda recently started decreasing its free license coverage to the point that even universities now have to purchase Anaconda for their non-education staff, who knows if we will be next. Miniforge offers the needed functionality with no hassle. 

To install miniforge if not yet installed:
- Go to [the download link](https://conda-forge.org/download/).
- Download the OS corresponding to your machine. (Likely Windows)
- Execute the downloaded installer.
- Open the cmd and try `>conda --version`.

If this fails, add conda to the path:
- Locate the path of your miniforge installation and copy it.
- In settings or windows search bar, look for environment variables.
- Edit "Path"
- Add the path to miniforge you copied as in my example: "C:\Users\hamza\miniforge3"
- Open the cmd and try `>conda --version`.

If this still fails:
- Add these additional relative paths as in my example:
"C:\Users\hamza\miniforge3\Library\mingw-w64\bin;C:\Users\hamza\miniforge3\Library\usr\bin;C:\Users\hamza\miniforge3\Library\bin;C:\Users\hamza\miniforge3\Scripts"
- Open the cmd and try `>conda --version`.

<!-- If this still fails:
- God help us all. -->

## Setting up our environment
- Open the cmd and run the following:

```
>conda create -n algo2class python=3.10 jupyterlab ipykernel networkx matplotlib tqdm pip numpy -y
```
Then activate the environment if you want to interact with python in the cmd terminal (you wont need it in VSCode):
```
>conda activate algo2class
```

## Jupyter Notebook
To work on the notebook:
- Launch VSCode.
- open the ".ipynb" file.
- in the top right, select kernel and choose the environment "algo2class".